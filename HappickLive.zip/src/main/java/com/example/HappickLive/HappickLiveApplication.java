package com.example.HappickLive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HappickLiveApplication {

	public static void main(String[] args) {
		SpringApplication.run(HappickLiveApplication.class, args);
	}

}
