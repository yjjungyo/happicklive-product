package com.example.HappickLive.service;

import java.util.List;

import com.example.HappickLive.domain.entity.Member;

public interface MemberService {
	List<Member> findAllMemberByTeamId(Long id);

}
