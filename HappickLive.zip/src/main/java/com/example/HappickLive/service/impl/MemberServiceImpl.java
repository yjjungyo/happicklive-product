package com.example.HappickLive.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.HappickLive.domain.entity.Member;
import com.example.HappickLive.domain.repository.MemberRepository;
import com.example.HappickLive.service.MemberService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class MemberServiceImpl implements MemberService {

	//@AutoWired 방식을 요즘에는 덜 선호한다.
	private final MemberRepository memberRepository;
	@Override
	public List<Member> findAllMemberByTeamId(Long id) {
		// TODO Auto-generated method stub
		return memberRepository.findAllMemberByTeamId(id);
	}
	
	

}
