package com.example.HappickLive.domain.vo;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor //lombok annotation
@NoArgsConstructor //lombok annotation
@Embeddable // variable object 로 만드는 annotation
public class Contact {

	@Column(name="email")
	private String email;
	@Column(name="mobile")
	private String mobile;
}
